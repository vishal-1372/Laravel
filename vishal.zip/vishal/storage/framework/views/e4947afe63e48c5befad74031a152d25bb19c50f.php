<?php $__env->startSection('content'); ?>
<h1>All the information will be displayed here....</h1>
<table class="table table-hover table-stripped table-sm table">
<thead>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Subtitle</th>
        <th>View</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
</thead>
<tbody>
    <?php $__empty_1 = true; $__currentLoopData = $myblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($myblog->id); ?></td>
            <td><?php echo e($myblog->title); ?></td>
            <td><?php echo e($myblog->subtitle); ?></td>
            <td>
                <a class="btn btn-md btn-danger" href="<?php echo e(route('myblog.show', $myblog->slug)); ?>">View Me!</a>
            </td>
            <td>
                <a class="btn btn-md btn-warning" href="<?php echo e(route('myblog.edit', $myblog->slug)); ?>">Edit Me!</a>
            </td>
            <td class="btn btn-md btn-info">Delete Me!</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan=6>No Data Avaialble</td>
    </tr>
    <?php endif; ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\atmiya140\Desktop\Laravel\vishal\resources\views/user/index.blade.php ENDPATH**/ ?>