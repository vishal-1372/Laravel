<h1>My Blog</h1>
<?php echo $__env->make('template.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\New folder (2)\myapp\Milan\resources\views/template/header.blade.php ENDPATH**/ ?>