<?php $__env->startSection('content'); ?>

<h2 align="center">Welcome....<?php echo e($hospital->name); ?></h2>
<style>
    table{
        width: 50%;
        /* border : 2px sold black ; */
    }
    td{
        padding : 5px;
        border : 2px solid black ;

    }

</style>
<table>
    <tr>
        <td>Patient Name :</td>
        <td><?php echo e($hospital->name); ?></td>
    </tr>
    <tr>
        <td>Mobile :</td>
        <td><?php echo e($hospital->number); ?></td>
    </tr>
    <tr>
        <td>Diseases :</td>
        <td><?php echo e($hospital->deseases); ?></td>
    </tr>
    <tr>
        <td>Medicines :</td>
        <td><?php echo e($hospital->medicines); ?></td>
    </tr>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\atmiya140\Desktop\Laravel\vishal\resources\views/show.blade.php ENDPATH**/ ?>