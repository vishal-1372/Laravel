<form method="post" action="<?php echo e(route('comments.store')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="myblog_id" value="<?php echo e($myblog->id); ?>">
    <input type="hidden" name="user_id" value="1">
    <div class="form-group">
        <label>Comments Please: </label>
        <textarea class="form-control" name="content" rows="3"></textarea>
      </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
<?php /**PATH F:\New folder (2)\myapp\Milan\resources\views/user/comments.blade.php ENDPATH**/ ?>