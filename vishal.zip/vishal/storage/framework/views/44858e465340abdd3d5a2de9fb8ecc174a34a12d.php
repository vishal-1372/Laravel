<?php $__env->startSection('content'); ?>
<h1>My Post goes here...</h1>

<h3>Title</h3>
<h3><?php echo e($myblog->title); ?></h3>

<h5>Subtitle</h5>
<h5><?php echo e($myblog->subtitle); ?></h5>

<p><?php echo e($myblog->body_content); ?></p>

<?php echo $__env->make('user.disp-comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('user.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\New folder (2)\myapp\Milan\resources\views/user/show.blade.php ENDPATH**/ ?>