<?php $__env->startSection('content'); ?>
<h1 align="center">Patient Details</h1>
<style>
    /* Styles for the table */
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #f2f2f2;
    }
    /* Add some hover effect */
    tr:hover {
        background-color: #f5f5f5;
    }
</style>
<table>
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Phone</th>
           <th>Show</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $patient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($patient->id); ?></td>
            <td><?php echo e($patient->name); ?></td>
            <td><?php echo e($patient->number); ?></td>
            <td>
                <a href="<?php echo e(route('Hospital.show',$patient->id)); ?>">Show</a>
            </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\atmiya140\Desktop\Laravel\vishal\resources\views/Home.blade.php ENDPATH**/ ?>