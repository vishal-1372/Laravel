<div class="card">
    <div class="card-header">
      Quote
    </div>
    <div class="card-body">
      <blockquote class="blockquote mb-0">
        <p>Copyright Information goes here...</p>
        <footer class="blockquote-footer">This is My Blog <cite title="Source Title">Containing some information for you</cite></footer>
      </blockquote>
    </div>
  </div>
<?php /**PATH F:\New folder (2)\myapp\Milan\resources\views/template/footer.blade.php ENDPATH**/ ?>