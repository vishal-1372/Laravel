<?php $__currentLoopData = $cs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card w-75">
    <div class="card-body">
      <h5 class="card-title"><?php echo e($c->user_id); ?> - <?php echo e($c->created_at); ?> </h5>
      <p class="card-text"><?php echo e($c->content); ?></p>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\New folder (2)\myapp\Milan\resources\views/user/disp-comments.blade.php ENDPATH**/ ?>