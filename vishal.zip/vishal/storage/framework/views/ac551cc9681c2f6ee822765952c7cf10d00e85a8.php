<h1>My Blog</h1>
<?php echo $__env->make('template.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\atmiya140\Desktop\Laravel\vishal\resources\views/template/header.blade.php ENDPATH**/ ?>