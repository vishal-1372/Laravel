<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Myblog extends Model
{
    use HasFactory;

    //protected $fillable = ['title','subtitle','user_id','body_content','slug'];
    protected $guarded = [];

    public function getComments(){
       return $this->hasMany(Comments::class,'myblog_id','id');
    }
    public function getRouteKeyName()
    {
        return 'slug';
    }
}
