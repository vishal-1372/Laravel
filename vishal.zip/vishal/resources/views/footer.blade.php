<footer style="background-color: #333; color: #fff; text-align: center; padding: 10px; margin-top: 50px;">
    <p>&copy; 2024 Hospital Management. All Rights Reserved.</p>
</footer>
